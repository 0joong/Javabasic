package operator;

public class example03 {
	public static void main(String[] args) {
	int x = 10;
	System.out.println(x);
	x += 2;
	System.out.println(x);
	x *= 2;
	System.out.println(x);
	x -= 2;
	System.out.println(x);
}
}
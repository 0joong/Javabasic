package print;

public class print02 {

	public static void main(String[] args) {
		String myName = "김영중";
		int myAge = 24;
	
		System.out.println("* 이름 :\t" + myName);
		System.out.println("* 나이 :\t" + myAge);
		
	}
	

}

package print;

public class print01 {

	public static void main(String[] args) {
		String myName = "김영중";
		int myAge = 24;
		
		System.out.println("* 이름 : " + myName);
		System.out.println("* 나이 : " + myAge);
		
		//System.out.print("* 이름 : " + myName);
		//System.out.print(" * 나이 : " + myAge);
		
	
		System.out.println("* 이름 : " + myName + " *나이 : " + myAge);
		
	}
	

}

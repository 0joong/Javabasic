package Variable;

public class Variable01 {

	public static void main(String[] args) {
		String myName = "김영중";
		int myAge = 24;
		System.out.println(myName);
		System.out.println(myAge);
		

		
		
		
	}

}

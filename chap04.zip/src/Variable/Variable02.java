package Variable;

public class Variable02 {

	public static void main(String[] args) {
		final double PI = 3.14;
		int r;
		r = 5;
		System.out.println(PI*r*r);

	}

}

package 과제;
import java.util.Scanner;

public class assignment04 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("금액을 입력하세요: ");
		int cash = scanner.nextInt();
		int won500=0;
		int won100=0;
		
		won500 = cash/500;
		won100 = cash%500/100;
		System.out.print("500원 동전"+won500+"개와 ");
		System.out.println("100원 동전"+won100+"개가 필요합니다.");
		
	}
}

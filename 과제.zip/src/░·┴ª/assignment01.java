package 과제;
import java.util.Scanner;
public class assignment01 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("정수타입 숫자를 입력하세요: ");
		int a=scanner.nextInt();
		System.out.println("실수타입 숫자를 입력하세요: ");
		double b=scanner.nextDouble();
		
		System.out.println(a + "+" + b + "=" +(a+b));
		System.out.println(a + "-" + b + "=" +(a-b));
		System.out.println(a + "*" + b + "=" +(a*b));
		System.out.println(a + "/" + b + "=" +(a/b));
	}

}


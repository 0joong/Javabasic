package 과제;
import java.util.Scanner;

public class assignment02 {

	public static void main(String[] args) {
		final double PI=3.14;
		Scanner scanner = new Scanner(System.in);
		System.out.println("원의 반지름 입력하세요");
		int i = scanner.nextInt();

		System.out.println("원의 넓이는" + i*i*PI+ "cm입니다.");
	}

}

package 과제;

import java.util.Scanner;

public class assignment03 {
	public static void main(String[] args) {
		int num1=0;
		int num2=0;
		int temp=0;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("변수 a에 넣을 숫자 입력");
		num1 = scanner.nextInt();
		System.out.println("변수 b에 넣을 숫자 입력");
		num2 = scanner.nextInt();
		
		temp = num1;
		num1= num2;
		num2 = num1;
		
		System.out.println("swapping 결과>");
		System.out.println("변수 a의 값: "+ num1);
		System.out.println("변수 b의 값: "+ num2);
		
	}
}

package method;

import java.util.Scanner;

public class Evenodd01 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int bContinue = 1;
		
		while(bContinue !=0) {
			decideEvenodd01();
			System.out.print("계속 하시겠습니까?(0/1)");
			bContinue = scanner.nextInt();			
		}
		
		System.out.println("다음에 또 봐요~~~^^");
	}
	
	static void decideEvenodd01() {
		System.out.print("숫자를 입력하세요: ");
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		if(num%2==0)
			System.out.println("짝수입니다");
		else
			System.out.println("홀수입니다");
	}
}

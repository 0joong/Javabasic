package method;

import java.util.Scanner;

public class Evenodd03 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int num=1;
		while(num!=0) {
			System.out.print("숫자를 입력하세요: ");
			num = scanner.nextInt();
			System.out.println(decideEvenOdd(num));
			System.out.println("계속 하실려면 1 아니면 0 입력하세요");
			num = scanner.nextInt();
		}

		System.out.println("다음에 또 만나요^^~~~");
	}
	public static String decideEvenOdd(int num) {
		if(num%2==0)
			return "짝수입니다.";
		else
			return "홀수입니다.";
	}
}

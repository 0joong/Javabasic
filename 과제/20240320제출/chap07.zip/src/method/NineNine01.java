package method;

import java.util.Scanner;

public class NineNine01 {
	
	public static void printNineNine(int num) {
		
		System.out.printf("구구단 %d단\n", num);
		for(int i =1;i<=9;i++) {
			System.out.printf("%d * %d = %d\n", num, i, num*i);
		}
		System.out.println();
		
	}

	public static void main(String[] args) {
		
		for(int i =2;i<=9;i++) {
			printNineNine(i);			
		}
	}
	
}

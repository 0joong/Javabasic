package method;

import java.util.Scanner;

public class Sum01 {
	
	public static int getNumberKeyboard(String message) {
		System.out.printf("%s", message);
		Scanner scanner = new Scanner(System.in);
		return scanner.nextInt();
	}
	
	public static int getSum(int number) {
		int sum = 0;
		for(int i =1;i<=number;i++) {
			sum+=i;
		}
		//System.out.printf("%d\n", sum);
		return sum;
	}
	
	public static void printScreen(int result) {
		System.out.printf("%d\n", result);
	}

	public static void printScreen(int value, String message) {
		System.out.printf("%s", message);
		System.out.printf("%d\n", value);
	}
	public static void main(String[] args) {
		
		int num;
		
		while((num=getNumberKeyboard("양의 숫자를 입력하세요"))>0) {
			int result = getSum(num);
			
			printScreen(result);
		}
		
		System.out.println("다음에또보자");

	}

}

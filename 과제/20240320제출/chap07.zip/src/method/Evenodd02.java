package method;

import java.util.Scanner;

public class Evenodd02 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int bContinue = 1;
		
		while(bContinue !=0) {
			System.out.print(decideEvenOdd());
			System.out.print("\n계속 하시겠습니까?(0/1)");
			bContinue = scanner.nextInt();			
		}
		
		System.out.println("다음에 또 봐요~~~^^");

	}
	
	public static String decideEvenOdd() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("숫자를 입력하세요: ");
		int num = scanner.nextInt();
		if(num%2==0)
			return "짝수입니다.";
		else
			return "홀수입니다.";
	}
}

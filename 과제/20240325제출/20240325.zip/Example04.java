package array;

public class Example04 {

	public static void main(String[] args) {
		int myarr[][] = {
				{1, 2, 3, 4, 5},
				{6, 7, 8, 9, 10},
				{11, 12, 13, 14, 15}
		};
		for(int row = 0;row <3; row++) {
			for(int col = 0;col<5; col++) {
				System.out.printf("myArr[%d][%d] ", row, col);
			}
			System.out.println();
		}
		System.out.printf("myArr[0][1] 값 : %d", myarr[0][1]);
	}

}

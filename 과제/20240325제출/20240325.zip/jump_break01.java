package jump;

import java.util.Scanner;

public class jump_break01 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int num = 0;
		int sum = 0;
		
		for(;;) {
			System.out.printf("양의 정수를 입력하세요 : ");
			num = scanner.nextInt();
			System.out.println();
			if(num<=0)
				break;

			for (int i = 0; i <= num; i++) {
				sum += i;
			}
			System.out.printf("%d부터 %d까지의 합 : %d\n", 1, num, sum);
			
			num=0;
			sum=0;
		}
		
	}

}

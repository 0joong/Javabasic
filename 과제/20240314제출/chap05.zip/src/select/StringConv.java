package select;

import java.util.Scanner;

public class StringConv {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.printf("새 개의 숫자를 입력해주세요: ");
		int a = Integer.parseInt(scanner.next());
		int b = Integer.parseInt(scanner.next());
		int c = Integer.parseInt(scanner.next());
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);

	}

}

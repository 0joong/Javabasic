package select;

import java.util.Scanner;

public class Example06 {

	public static void main(String[] args) {
		System.out.println("1. 아메리카노");
		System.out.println("2. 카페라떼");
		System.out.println("3. 카푸치노");
		System.out.println("4. 돌체라떼");
		System.out.print("메뉴 번호를 선택하세요 : ");
		
		Scanner scanner = new Scanner(System.in);
		int menu = scanner.nextInt();
		switch (menu) {
		case 1:
		case 2:
		case 3:
			System.out.print("몇 잔을 주문하시겠습니까? ");
			int coffee = scanner.nextInt();
			System.out.println(menu + "번 메뉴를 " + coffee + "잔 주문하셨습니다.");
			break;
		default:
			System.out.println("없는 메뉴입니다.");
		}

	}

}

package select;

import java.util.Scanner;

public class If02 {

	public static void main(String[] args) {
		System.out.printf("숫자를 입력하세요: ");
		Scanner scanner = new Scanner(System.in);
		int input = scanner.nextInt();
		
		if(input%2==0)
			System.out.println("짝수입니다");
		else
			System.out.println("홀수입니다");

	}

}

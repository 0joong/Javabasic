package select;

import java.util.Scanner;

public class Switch01 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("숫자치세요: ");
		int num =scanner.nextInt();

		
		switch((num%2==0) ? 1 : 0) {
		case 1: System.out.println("짝수입니다");break;
		
		case 0: System.out.println("홀수입니다");break;
		}

	}

}

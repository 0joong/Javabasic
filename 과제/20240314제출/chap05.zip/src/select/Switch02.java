package select;

import java.util.Scanner;

public class Switch02 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("학점 입력하세요: ");
		char ch = scanner.next().charAt(0);
		switch(ch) {
		case 'A', 'a', 'B', 'b' -> System.out.println("아주 열심히 하셨군요~~~!");
		case 'C', 'c' -> System.out.println("남들만큼 하셨네요~~~");
		case 'D', 'd' -> System.out.println("조금 더 노력이 필요합니다");
		case  'f', 'F' ->System.out.println("교수실로 찾아오세요");
		}

	}

}

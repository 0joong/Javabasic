package chap02;

import java.util.Scanner;

public class chap02_02 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.printf("정수를 입력하세요: ");
		int num = scanner.nextInt();
		System.out.printf("%d의 제곱은 %d", num, num*num);
	}

}

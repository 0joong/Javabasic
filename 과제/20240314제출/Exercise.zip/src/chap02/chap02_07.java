package chap02;

import java.util.Scanner;

public class chap02_07 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("숫자 입력: ");
		int num = scanner.nextInt();
		System.out.printf("4와 5 둘 다로 나누어지는가? %b\n", num%4==0 && num%5==0);
		
		System.out.printf("4 또는 5로 나누어지는가? %b\n", num%4==0 || num%5==0);
		
		if(num%4==0 || num%5==0) {
			if(num%4==0 && num%5==0)
				System.out.printf("4 또는 5 하나로만 나누어지는가? false\n");
			else
				System.out.printf("4 또는 5 하나로만 나누어지는가? true\n");
		}
	


	}

}

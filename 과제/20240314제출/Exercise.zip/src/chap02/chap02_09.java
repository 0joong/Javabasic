package chap02;

import java.util.Scanner;

public class chap02_09 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("전공 이수 학점: ");
		int credit1 = scanner.nextInt();
		System.out.println("교양 이수 학점: ");
		int credit2 = scanner.nextInt();
		System.out.println("일반 이수 학점: ");
		int credit3 = scanner.nextInt();
		
		if(credit1>=70 && ((credit2>=30 && credit3>=30) || (credit2+credit3)>=80))
			System.out.println("졸업 가능");
		else
			System.out.println("졸업 불가");
	}

}

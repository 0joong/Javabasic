package chap02;

import java.util.Scanner;

public class chap02_08 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		System.out.print("0~999사이 숫자 입력하세요: "); 
		int num = scanner.nextInt();
		System.out.printf("각 자릿수의 합: %d", num%10+num/10%10, num/10/10%10);
	}

}

package chap02;
import java.util.*;

public class chap02_03 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.printf("원기둥의 밑면 반지름은? ");
		double radius = scanner.nextDouble();
		System.out.printf("원기둥의 높이는? ");
		double height = scanner.nextDouble();
		System.out.printf("원기둥의 부피는 %.1f", radius*radius*3.14*height);
	}

}

package chap02;

import java.util.Scanner;

public class chap02_06 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("온도 입력하세요: ");
		double input = scanner.nextDouble();
		
		System.out.printf("변환된 온도: %.2f", (input-32)*5/9);

	}

}

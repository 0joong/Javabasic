package chap02;

import java.util.Scanner;

public class chap02_04 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("초 단위 정수를 입력하세요 : ");
		int second = scanner.nextInt();
		int hour = second/3600;
		int min = second%3600/60;
		second %=60;
		
		System.out.printf("%d시간 %d분 %d초", hour, min, second);
	}

}

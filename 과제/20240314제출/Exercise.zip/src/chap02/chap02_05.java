package chap02;

import java.util.Scanner;

public class chap02_05 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.printf("소문자 입력하세요: ");
		char ch = scanner.next().charAt(0);
		
		System.out.println("대문자 변환 결과 :" + (char)(ch-32));
		//System.out.printf("%d", (int)'A'-(int)'a');

	}

}


package chap02;

public class chap02_01 {

	public static void main(String[] args) {
		System.out.printf("      *\n");
		System.out.printf("     ***\n");
		System.out.printf("    *****\n");
		System.out.printf("   *******\n");
		System.out.printf("  *********\n");
		System.out.printf(" ***********\n");
	}

}
